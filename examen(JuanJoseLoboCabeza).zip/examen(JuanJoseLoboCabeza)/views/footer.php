<footer class="bg-dark color-primary text-body-secondary py-4 text-center">
    <p>© 2024 P.Lluyot. Todos los derechos reservados.</p>
</footer>